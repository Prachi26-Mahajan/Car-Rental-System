<?php
include "connection.php";
$q = $_REQUEST["q"];
$select_Car = "select * from cars where car_name='$q'";
$result_Car = mysqli_query($conn, $select_Car);


$row_Cars = mysqli_fetch_array($result_Car);
?>
<!DOCTYPE>
<html>
<head>
    <?php
    include "headerfiles.php";
    ?>
<!--    <link href="css/bootstrap.css" rel="stylesheet">-->
<!--    <script src="jquery-3.2.0.min.js"></script>-->
    <script src="dist/jquery.validate.js"></script>
    <script>
        $(document).ready(function () {
//            alert("jquery ready");
            $("#form1").validate();
        })
    </script>
</head>

<body>
<?php
//include "adminheader.php";
include "adminheaderTEMPLATE.php";
?>

<div class="container">
<h1>Edit Car</h1>
    <form action="cars_update_action.php" method="post" id="form1" enctype="multipart/form-data">
        <div class="form-group">
            Enter car name
            <input type="text" class="form-control" name="carname" value="<?php echo $row_Cars[0]; ?>" readonly
                   data-rule-required="true"
                   data-msg-required="carname Required">
        </div>

        <div class="form-group">
            Enter brand
            <input type="text" class="form-control" name="brand" data-rule-required="true"
                   value="<?php echo $row_Cars[1]; ?>"
                   data-msg-required="brand Required">
        </div>
        <div class="form-group">
            Insert photo
            <img src="<?php echo $row_Cars[3]; ?>" height="100">

            <input type="file" class="form-control" name="photo">
        </div>
        <div class="form-group">
            Enter description

            <textarea class="form-control" name="description"><?php echo $row_Cars[2]; ?></textarea>
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-success" value="submit" data-rule-required="true">
        </div>
    </form>
    <?php
    if (isset($_GET['msg'])) {
        $msg = $_GET['msg'];
        if ($msg == 1) {
            echo '<span class="alert alert-danger">Car Already Exist</span>';
        } elseif ($msg == 2) {
            echo '<span class="alert alert-danger">Car Added Successfully</span>';
        } else {
            echo '<span class="alert alert-danger">Size is greater than 5MB</span>';
        }
    }
    ?>
</div>
<?php
include "footertemplate.php";
?>
</body>

</html>