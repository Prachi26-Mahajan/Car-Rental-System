<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
<!--    <link rel="stylesheet" href="css/bootstrap.css">-->
    <?php
    include "headerfiles.php";
    ?>
</head>
<body>
<?php
//include "userheader.php";
include "userheaderTEMPLATE.php";
?>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <?php
            if (isset($_GET['msg'])) {
                ?>
                <h1>Car Booked Successfully</h1>
                <?php
            }
            ?>
            <br>
            <br>
            <br>
        </div>
    </div>
</div>
<?php
include "footertemplate.php";
?>
</body>
</html>