<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
    include "headerfiles.php"
    ?>
<!--    <link rel="stylesheet" href="css/bootstrap.css">-->
</head>
<body>
<?php
//include "adminheader.php";
include "adminheaderTEMPLATE.php";
?>
<div class="container">
    <div class="row">
        <div class="col-sm-12 col-md-12">
            <h1>Add Areas</h1>
            <form method="post" action="areasaction.php">
                <div class="form-group">
                    <label>Select City</label>
                    <select class="form-control" name="city_id">
                        <option>Select City</option>
                        <?php
                        include "connection.php";
                        $select_cities = "select city_id,cityname from cities";
                        $result_cities = mysqli_query($conn, $select_cities);
                        while ($row_cities = mysqli_fetch_array($result_cities)) {
                            ?>
                            <option value="<?php echo $row_cities[0]; ?>"><?php echo $row_cities[1]; ?></option>
                            <?php
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Area Name</label>
                    <input type="text" name="areaname" class="form-control">
                </div>
                <div class="form-group">
                    <input type="submit" value="submit" class="btn btn-success">
                </div>
            </form>
        </div>
    </div>
</div>
<?php
include "footertemplate.php";
?>
</body>
</html>