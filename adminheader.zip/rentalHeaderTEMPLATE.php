<?php
session_start();
if (!isset($_SESSION["rental_email"])) {
    header("location:rental_login.php");
} else {
    $email = $_SESSION["rental_email"];
    $rental_id = $_SESSION["rental_id"];
}
?>


<!-- banner -->
<!--<div class="banner-w3ls" id="home">-->
<div id="home">
    <!-- header -->
    <div class="header-w3l-agile">
        <div class="header_left">
            <ul>
                <li><a href="ishan.bhalla89@gmail.com"><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>ishan.bhalla89@gmail.com</a></li>
                <li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>+91 9888829878</li>
            </ul>
        </div>
        <!--        <div class="header_right">-->
        <!--            <div class="w3ls-social-icons">-->
        <!--                <a class="facebook" href="#"><i class="fa fa-facebook"></i></a>-->
        <!--                <a class="twitter" href="#"><i class="fa fa-twitter"></i></a>-->
        <!--                <a class="pinterest" href="#"><i class="fa fa-google-plus"></i></a>-->
        <!--                <a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a>-->
        <!---->
        <!--            </div>-->
        <!--        </div>-->
        <div class="clearfix"></div>
    </div>
    <!-- //header -->
    <div class="container">
        <div class="header-nav">
            <nav class="navbar navbar-default">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <h4><a  href="index.html"><span class="logo-c" style="color:#f5af02;">C</span><i class="fa fa-car" aria-hidden="true"></i> Fusion</a><p class="sub-cap">Drive to Any where</p></h4>
                </div>
                <!-- navbar-header -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="rentalhome.php" class="hvr-underline-from-center active"><span class="glyphicon glyphicon-home"></span></a></li>
                        <li><a href="view_bookings.php" class="hvr-underline-from-center active">Bookings</a></li>
                        <li><a href="view_report.php" class="hvr-underline-from-center active">Report</a></li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">MANAGE <span class="fa fa-car"></span><span
                                        class="caret"></span></a>
                            <ul class="dropdown-menu">

                                <li><a href="mycars.php">Add Cars</a></li>
                                <li><a href="rentalMycars.php">View Cars</a></li>
                            </ul>
                        </li>
<!--                        <li><a href="mycars.php" class="hvr-underline-from-center scroll">Add Cars</a></li>-->
<!--                        <li><a href="rentalMycars.php" class="hvr-underline-from-center ">View Cars</a></li>-->



                        <li><a href="areas_choose.php" class="hvr-underline-from-center ">Choose Areas</a></li>
                        <li><a href="blacklist_rentalcars.php" class="hvr-underline-from-center ">BlackList <span class="fa fa-car"></span></a></li>


                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span
                                        class="glyphicon glyphicon-wrench caret"></span></a>
                            <ul class="dropdown-menu">

                                <li><a href="rental_changepassword.php">Change Password</a></li>
                                <li><a href="rental_logout.php">Logout <?php echo $_SESSION['rental_email']; ?></a></li>
                            </ul>
                        </li>


                    </ul>
                </div>
                <div class="clearfix"> </div>
            </nav>

        </div>
        <div class="clearfix"></div>

        <!--timer-->


        <!--//timer-->

    </div>


</div>