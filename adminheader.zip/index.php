<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
    <title>Car Rental An Auto mobile Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
    <!-- for-mobile-apps -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="Car Rental Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"/>
    <?php
    include "headerfiles.php";
    ?>

</head>
<body>

<?php
include "publicheaderTEMPLATE.php";
?>

<!-- //banner -->
<!-- bootstrap-pop-up -->
<div class="modal video-modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">

                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
            </div>
            <section>
                <div class="modal-body">
                    <h3 class="agileinfo_sign">BEFRIEND</h3>
                    <img src="images/g1.jpg" alt=" " class="img-responsive"/>
                    <p>Ut enim ad minima veniam, quis nostrum
                        exercitationem ullam corporis suscipit laboriosam,
                        nisi ut aliquid ex ea commodi consequatur.
                        <i>" Quis autem vel eum iure reprehenderit qui in ea voluptate velit .</i></p>
                </div>
            </section>
        </div>
    </div>
</div>
<!-- //bootstrap-pop-up -->
<!-- /banner-bottom -->
<div class="banner-bottom">
    <!--//screen-gallery-->
    <div class="wthree_title_agile">
        <h3>Most <span>Popular</span> Cars</h3>
    </div>
    <p class="sub_para">It’s time to drive</p>
    <div class="inner_w3l_agile_grids">
        <div class="sreen-gallery-cursual">

            <div id="owl-demo" class="owl-carousel">
                <?php
                include "connection.php";
                $mycars = "select coverphoto, rent from mycars";
                $res_mycars = mysqli_query($conn, $mycars);
                while ($row_mycars = mysqli_fetch_array($res_mycars)) {
                    ?>
                    <div class="item-owl">
                        <div class="test-review">
                            <!--                            <img src="images/s1.jpg" class="img-responsive" alt=""/>-->
                            <img src="<?php echo $row_mycars[0]; ?>" class="img-responsive" alt=""/>
                            <!--                            <h5>$280</h5>-->
                            <h5>&#8377; <?php echo $row_mycars[1]; ?></h5>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <!--//screen-gallery-->
        </div>
    </div>
</div>
<!-- //banner-bottom -->


<!-- about -->
<div class="about" id="about">
    <div class="container">
        <div class="wthree_title_agile two">
            <h3>About <span>Us</span></h3>
        </div>
        <p class="sub_para two">It’s time to drive</p>
        <div class="inner_w3l_agile_grids">
            <div class="col-md-12 about-left-w3layouts">
                <h6 class="sub">WELCOME TO OUR Cars Fusion</h6>
                <p>No more worries about petrol mileage, fuel costs, insurance, and car breakdowns! Cars Fusion has enabled
                    driving convenience for travellers around the country and is fast expanding its reach to cities
                    including Amritsar, Jalandhar, Ludhiana, Mohali. Self drive cars from Cars Fusion have given customers
                    more control, privacy, and freedom. Book a selfdrive car in any city you visit and feel at home
                    wherever you go.</p>
            </div>
            <div class="col-md-6 about-right-w3layouts">
                <!--                <iframe src="https://player.vimeo.com/video/9677468" frameborder="0"></iframe>-->
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!--about-section-->

<!-- about -->

<!--//service-section-->


<div class="lb-overlay" id="image-1">
    <img src="images/g1.jpg" alt="image1"/>
    <div class="gal-info">
        <h3>Car Rental</h3>
        <p>Neque porro quisquam est, qui dolorem ipsum
            quia dolor sit amet, consectetur, adipisci velit,
            sed quia non numquam eius modi tempora incidunt ut
            labore et dolore magnam aliquam quaerat voluptatem.</p>
    </div>
    <a href="index.html" class="lb-close">Close</a>
</div>
<div class="lb-overlay" id="image-2">
    <img src="images/g2.jpg" alt="image1"/>
    <div class="gal-info">
        <h3>Car Rental</h3>
        <p>Neque porro quisquam est, qui dolorem ipsum
            quia dolor sit amet, consectetur, adipisci velit,
            sed quia non numquam eius modi tempora incidunt ut
            labore et dolore magnam aliquam quaerat voluptatem.</p>
    </div>
    <a href="index.html" class="lb-close">Close</a>
</div>
<div class="lb-overlay" id="image-3">
    <img src="images/g3.jpg" alt="image1"/>
    <div class="gal-info">
        <h3>Car Rental</h3>
        <p>Neque porro quisquam est, qui dolorem ipsum
            quia dolor sit amet, consectetur, adipisci velit,
            sed quia non numquam eius modi tempora incidunt ut
            labore et dolore magnam aliquam quaerat voluptatem.</p>
    </div>
    <a href="index.html" class="lb-close">Close</a>
</div>
<div class="lb-overlay" id="image-4">
    <img src="images/g4.jpg" alt="image1"/>
    <div class="gal-info">
        <h3>Car Rental</h3>
        <p>Neque porro quisquam est, qui dolorem ipsum
            quia dolor sit amet, consectetur, adipisci velit,
            sed quia non numquam eius modi tempora incidunt ut
            labore et dolore magnam aliquam quaerat voluptatem.</p>
    </div>
    <a href="index.html" class="lb-close">Close</a>
</div>
<div class="lb-overlay" id="image-5">
    <img src="images/g5.jpg" alt="image1"/>
    <div class="gal-info">
        <h3>Car Rental</h3>
        <p>Neque porro quisquam est, qui dolorem ipsum
            quia dolor sit amet, consectetur, adipisci velit,
            sed quia non numquam eius modi tempora incidunt ut
            labore et dolore magnam aliquam quaerat voluptatem.</p>
    </div>
    <a href="index.html" class="lb-close">Close</a>
</div>
<div class="lb-overlay" id="image-6">
    <img src="images/g6.jpg" alt="image1"/>
    <div class="gal-info">
        <h3>Car Rental</h3>
        <p>Neque porro quisquam est, qui dolorem ipsum
            quia dolor sit amet, consectetur, adipisci velit,
            sed quia non numquam eius modi tempora incidunt ut
            labore et dolore magnam aliquam quaerat voluptatem.</p>
    </div>
    <a href="index.html" class="lb-close">Close</a>
</div>
<div class="lb-overlay" id="image-7">
    <img src="images/g7.jpg" alt="image1"/>
    <div class="gal-info">
        <h3>Car Rental</h3>
        <p>Neque porro quisquam est, qui dolorem ipsum
            quia dolor sit amet, consectetur, adipisci velit,
            sed quia non numquam eius modi tempora incidunt ut
            labore et dolore magnam aliquam quaerat voluptatem.</p>
    </div>
    <a href="index.html" class="lb-close">Close</a>
</div>
<div class="lb-overlay" id="image-8">
    <img src="images/g8.jpg" alt="image1"/>
    <div class="gal-info">
        <h3>Car Rental</h3>
        <p>Neque porro quisquam est, qui dolorem ipsum
            quia dolor sit amet, consectetur, adipisci velit,
            sed quia non numquam eius modi tempora incidunt ut
            labore et dolore magnam aliquam quaerat voluptatem.</p>
    </div>
    <a href="index.html" class="lb-close">Close</a>
</div>
<!-- gallery -->


<!-- /contact -->
<div class="map-w3ls">
    <div class="wthree_title_agile" id="contact">
        <h3> Contact <span>Us</span></h3>
    </div>
    <p class="sub_para">It’s time to drive</p>
    <div class="contact-agile" >
        <div class="contact-middle">
            <h4>Say Hello</h4>
            <form action="#" method="post">
                <div class="form-agileinfo">
                    <div class="input-w3ls">
                        <p>Your Name</p>
                        <input type="text" name="your name" placeholder="" required=""/>
                    </div>
                    <div class="input-w3ls">
                        <p>Your Email</p>
                        <input type="email" name="Your email" placeholder="" required=""/>
                    </div>
                </div>
                <div class="form-agileits-w3layouts">
                    <p>Your Comments</p>
                    <textarea name="your message" placeholder="" required=""></textarea>
                    <input type="submit" value="Send message">
                </div>
                <div class="clearfix"></div>
            </form>
        </div>
        <div class="contact-left">
            <h6>89 Joshi Colony,Mall Rd, ASR.</h6>
            <p>(+91) 9888829878</p>
            <!--            <p>Inner Ring W, Hounslow TW6 1BP, UK</p>-->
            <p><a href="mailto:ishan.bhalla89@gmail.com">ishan.bhalla89@gmail.com</a></p>
            <h6>Opening Hours</h6>
            <p>Monday-Friday</p>
            <!--            <span>7.00AM-10.00PM</span>-->
            <span>24hrs</span>
            ​<p>Saturday-Sunday</p>
            ​<span>24hrs</span>
        </div>

    </div>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1233.8968956351416!2d74.9904393305695!3d31.577140722014992!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x391bd63f85203271%3A0x57ec6504e6d034f4!2sAmritsar+College+of+Engineering+and+Technology!5e1!3m2!1sen!2sin!4v1510729023226"
            width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>

</div>
<!-- //contact -->

<?php
include "footertemplate.php";
?>

</body>
</html>