# Responsive-Ticker
Fully responsive ticker using HTML5, CSS3, JavaScript, jQuery
