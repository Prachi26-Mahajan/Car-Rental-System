<!DOCTYPE>
<html>

<head>
    <?php
    include "headerfiles.php";
    ?>
<!--    <link href="css/bootstrap.css" rel="stylesheet">-->
</head>

<body>
<?php

//include "userheader.php";
include "userheaderTEMPLATE.php";
?>
<div class="container">
    <h1>Welcome to User Home <?php echo $email ?></h1>

</div>
<br>
<br>
<br>
<br>
<br>
<br>
<?php
include "footertemplate.php";
?>
</body>
</html>