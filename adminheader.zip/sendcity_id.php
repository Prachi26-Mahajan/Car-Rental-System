<?php
session_start();
include 'connection.php';
$email = $_SESSION["rental_email"];
$rental_id = $_SESSION["rental_id"];


$city_id = $_REQUEST['city_id'];

?>
<div id="output">
    <h1>Available Areas</h1>
    <div class="row jumbotron">
        <?php
        $sel_areas = "select * from Areas WHERE city_id='$city_id'";
        $result_area_name = mysqli_query($conn, $sel_areas);
        while ($row_area = mysqli_fetch_array($result_area_name)) {
            $sql = "select * from `rental_areas` where area_id=" . $row_area[0] . " and rental_id='$rental_id'";
            $sql_result = mysqli_query($conn, $sql);
            $sql_row = mysqli_fetch_array($sql_result);
            ?>
            <div class="col-sm-3 col-md-3 col-lg-3">
                <input type="checkbox" <?php if ($row_area[0] == $sql_row[1]) { ?>checked<?php } ?>
                       value="<?php echo $row_area['area_id']; ?>"
                       name="ch[]" id="area_id"> <?php echo $row_area['areaname']; ?>
            </div>
            <?php

        }
        ?>
    </div>

    <div class="form-group">
        <input type="submit" value="Add Areas" class="btn btn-primary">
    </div>
</div>
