<?php

session_start();
if(is_null($_SESSION["email"]))
{
    header("location: login.php");
}
else
{
    $email=$_SESSION["email"];
}
?>


<div>
    <ul class="nav nav-pills">
        <li><a href="adminhome.php">Admin Home</a> </li>
        <li><a href="manageadmin.php">Manage Administrators</a> </li>
        <li><a href="cars.php">Add Cars</a> </li>
        <li><a href="view_cars.php">view Cars</a> </li>
        <li><a href="view_rentals.php">Rentals</a> </li>
        <li><a href="cityadd.php">Add Cities</a> </li>
        <li><a href="cityview.php">View Cities</a> </li>
        <li><a href="areas.php">Add Area</a> </li>
        <li><a href="areasview.php">Area View</a> </li>
        <li><a href="managenews.php">Manage News</a> </li>
        <li><a href="changepassword.php">Change Password</a> </li>
        <li><a href="logout.php">Logout</a> </li>

    </ul>
</div>