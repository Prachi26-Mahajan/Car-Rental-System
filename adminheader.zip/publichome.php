<?php
include "connection.php";
$sel_cityname = "select * from cities";
$res_cityname = mysqli_query($conn, $sel_cityname);

$cityname_in_array = "[";

while ($row_cityname = mysqli_fetch_array($res_cityname)) {
    $cityname_in_array .= "'" . $row_cityname['cityname'] . "',";
}
$cityname_in_array = trim($cityname_in_array, ",");
$cityname_in_array .= "]";

?>

<!doctype html>
<html>
<head>
<!--    <link href="css/bootstrap.css" rel="stylesheet">-->
<!--    <link rel="stylesheet" href="jquery-ui.css">-->
<!--    <link rel="stylesheet" type="text/css" href="ticker.css">-->
<!--    <script src="jquery-3.2.0.min.js"></script>-->
<!--    <script src="js/myscript.js" type="text/javascript"></script>-->
<!--    <script src="jquery-ui.js" type="text/javascript"></script>-->
    <?php
    include "headerfiles.php";
    ?>
    <script>
        $(document).ready(function () {
            var cname = <?php echo $cityname_in_array ?>;
            $("#cityname").autocomplete({
                source: cname
            });
        });

    </script>
    <script src="ticker.js"></script>


    <link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
    <style>
        body {
            /*background-color: #ddd;*/
        }

        h1 {
            margin: 150px auto 100px auto;
            text-align: center;
        }
    </style>

</head>
<body>
<?php
@session_start();
if (!isset($_SESSION["useremail"])) {
    include "publicheaderTEMPLATE2.php";
} else {
    include "publicheaderTEMPLATE.php";
}


$query = "select * from news order by newsid desc LIMIT 0,5";
$result = mysqli_query($conn, $query);
$s = "";
while ($row = mysqli_fetch_array($result)){
    $s = $s . "<div><li><span>" . $row[1] . "</span></li></div>";
}
?>

<div class="ticker-container">
    <div class="ticker-caption">
        <p>Breaking News</p>
    </div>
    <ul>
        <?php
        echo $s;
        ?>
    </ul>
</div>
<div class="container">
    <script type="text/javascript">

        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-36251023-1']);
        _gaq.push(['_setDomainName', 'jqueryscript.net']);
        _gaq.push(['_trackPageview']);

        (function () {
            var ga = document.createElement('script');
            ga.type = 'text/javascript';
            ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(ga, s);
        })();

    </script>
    <div class="row">
        <div class="col-md-3">

            <div class="form-group">
                <input type="text" class="form-control" id="cityname" placeholder="Enter City Name">
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <input type="button" class="btn btn-primary" value="Get Areas" onclick="get_public_area()" style="background-color: #e3001f">
            </div>
        </div>
        <div class="col-md-6"></div>
    </div>
    <div class="row">
        <div id="areaname_in_div"></div>
    </div>
    <br>
    <div id="showavailablerental"></div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<?php
include "footertemplate.php";
?>
</body>
</html>