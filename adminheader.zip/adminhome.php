<!DOCTYPE>
<html>

<head>
    <?php
    include "headerfiles.php";
    ?>
<!--    <link href="css/bootstrap.css" rel="stylesheet">-->
</head>

<body>
<?php

//include "adminheader.php";
include "adminheaderTEMPLATE.php";
?>
<div class="container">

    <h1>Welcome to admin Home <?php echo $_SESSION["email"] ?></h1>

</div>
<?php
include "footertemplate.php";
?>
</body>
</html>