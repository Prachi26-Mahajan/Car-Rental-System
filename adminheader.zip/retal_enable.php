<?php
include 'connection.php';
$id = $_REQUEST['q'];
$stat = $_REQUEST['stat'];

if ($stat == 'Pending') {
    $update = "update rental_signup set Status='Active' WHERE ID=" . $id;
} else {
    $update = "update rental_signup set Status='Pending' WHERE ID=" . $id;
}
mysqli_query($conn, $update);
header("Location:view_rentals.php");