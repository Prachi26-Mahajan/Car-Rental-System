<div>
    <ul class="nav nav-pills">
        <li><a href="publichome.php">Home</a> </li>
        <li><a href="">Contact us</a> </li>
        <li><a href="">About us</a> </li>
        <li><a href="public_signUp.php">Sign Up</a> </li>
        <li><a href="public_login.php">Login</a> </li>
        <li><a href="rental_signup.php">Rental Sign Up</a> </li>
        <li><a href="rental_login.php">Rental Login</a> </li>

    </ul>
</div>