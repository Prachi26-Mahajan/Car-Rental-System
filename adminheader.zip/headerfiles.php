<script src="jquery-3.2.0.min.js"></script>

<script type="application/x-javascript"> addEventListener("load", function () {
        setTimeout(hideURLbar, 0);
    }, false);

    function hideURLbar() {
        window.scrollTo(0, 1);
    } </script>
<!-- //for-mobile-apps -->


<script src="jquery-ui.js" type="text/javascript"></script>

<script src="js/myscript.js" type="text/javascript"></script>
<script src="js/bootstrap.js"></script>

<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/galleryeffect.css" rel="stylesheet" type="text/css" media="all"/>
<link rel="stylesheet" href="css/jquery.flipster.css">
<link rel='stylesheet' href='css/dscountdown.css' type='text/css' media='all'/>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/font-awesome.css" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Press+Start+2P" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Faster+One" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">

<link rel="stylesheet" href="jquery-ui.css">
<link rel="stylesheet" type="text/css" href="ticker.css">
<style>
    .mybuttonmy {
        color: #e3001f;
        background: #e3001f;
    }
</style>