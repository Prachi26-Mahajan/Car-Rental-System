<?php
$mycar_id = $_GET['mycar_id'];
$useremail = $_GET['useremail'];

$startdate = date('Y-m-d',strtotime($_GET['startdate']));
$enddate = date('Y-m-d',strtotime($_GET['enddate']));
$numberofdays = $_GET['numberofdays'];

$gst_percent = 12;

$grandtotal = $_GET['grandtotal'] / 100;


date_default_timezone_set("Asia/Kolkata");
$date = date("Y-m-d");
//echo $date;


include "connection.php";
$insert = "insert into bills VALUES (NULL ,$mycar_id,'$useremail','$startdate','$enddate',$numberofdays,12,$grandtotal,'$date')";
mysqli_query($conn, $insert);

header("location:view_report.php");

